<?php

return [
    'Sign_flg'                                     => '签到活动',
    'Continuity_give_number'                       => '每天签到赠送',
    'Continuity_give_placeholder'                  => '设置签到赠送VIP的天数或者赠送积分的数量',
    'Seven_days_give_number'                       => '连续7天送',
    'Seven_days_giv_placeholder'                   => '设置签到赠送VIP的天数或者赠送积分的数量',
    'Invite_flg'                                   => '邀请好友',
    'Invite_stage_number'                          => '每邀请',
    'Invite_stage_give_number'                     => '个好友，赠送',
    'Invite_stage_placeholder'                     => '设置签到赠送VIP的天数或者赠送积分的数量',
    'Invite_total_number'                          => '累计邀请',
    'Invite_total_give_number'                     => '个好友，赠送',
    'Invite_total_placeholder'                     => '设置签到赠送VIP的天数或者赠送积分的数量',
    'Ip_repeat_flg'                                => 'IP去重',
    'Ip_repeat_placeholder'                        => '开启后，同一IP注册的用户将不被记入邀请个数',
    'Create_time'                                  => '创建记录',
    'Update_time'                                  => '更新时间',
    'Enable'                                       => '启用',
    'Disable'                                      => '禁用',
    'Vip'                                          => 'VIP',
    'Integral'                                     => '积分',
];
