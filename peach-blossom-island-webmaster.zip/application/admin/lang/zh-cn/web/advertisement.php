<?php

return [
    'Position'                  => '位置',
    'Title'                     => '广告标题',
    'Url'                       => 'URL',
    'Jump_Url'                  => '跳转URL',
    'Image_pc'                  => '广告图PC',
    'Image_h5'                  => '广告图H5',
    'Video'                     => '广告视频',
    'Type'                      => '类型',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Type_fixed'                => '固定广告位',
    'Type_js'                   => 'JS广告',
    'Type_mult'                 => '多值广告位',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
    'Alliance JS code'          => '联盟JS代码',
    'Recommended size'          => '该图片建议尺寸',
];
