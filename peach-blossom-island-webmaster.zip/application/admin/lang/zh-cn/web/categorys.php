<?php

return [
    'Index'                     => '排序',
    'Name'                      => '分类名称',
    'Pinyin'                    => '分类拼音',
    'Belong_to'                 => '所属上级',
    'Logo'                      => '分类Logo',
    'Front'                     => '分类封面图',
    'Map_to'                    => '映射分类',
    'Map_name'                  => '映射分类',
    'Mode'                      => '模式',
    'Integral'                  => '积分',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Mode_free'                 => '免费',
    'Mode_vip'                  => 'VIP',
    'Mode_reflect'              => '点映',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
    'Top_category'              => '顶级分类',
    'Mode_reflect_integral'     => '点映所需积分',

    'Please enter the points required for the score'               => '请输入点映所需积分',
];
