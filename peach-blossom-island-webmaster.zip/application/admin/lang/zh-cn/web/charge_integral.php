<?php

return [
    'Index'                     => '排序',
    'Name'                      => '选项名称',
    'Integral'                  => '积分数',
    'Plus_free'                 => '赠送积分',
    'Amount'                    => '金额',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
];
