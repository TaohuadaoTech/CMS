<?php

return [
    'Index'                     => '排序',
    'Name'                      => '站点名称',
    'Url'                       => '站点跳转地址',
    'Logo'                      => '站点Logo',
    'Type_id'                   => '站点所属类别ID',
    'Type_name'                 => '分类名称',
    'Weight'                    => '权重传递',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Weight_Enable'             => '启用',
    'Weight_Disable'            => '禁用',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
];
