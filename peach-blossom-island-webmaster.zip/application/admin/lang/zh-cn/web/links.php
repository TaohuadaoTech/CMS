<?php

return [
    'Index'                     => '排序',
    'Name'                      => '友链名称',
    'Url'                       => '跳转地址',
    'Weight'                    => 'SEO状态',
    'Uv_from'                   => '日来路流量',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Weight_Yes'                => '允许',
    'Weight_No'                 => '禁止',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
];
