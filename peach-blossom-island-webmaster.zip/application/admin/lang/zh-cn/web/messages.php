<?php

return [
    'Index'                       => '排序',
    'Name'                        => '公告名称',
    'Type_id'                     => '消息分类id',
    'Type_name'                   => '公告分类',
    'Content'                     => '消息内容',
    'Read_flg'                    => '是否已读',
    'Status'                      => '状态',
    'Create_time'                 => '创建成功',
    'Update_time'                 => '更新时间',
    'Read_flg_yes'                => '已读',
    'Read_flg_no'                 => '未读',
    'Status_Enable'               => '启用',
    'Status_Disable'              => '禁用',
];
