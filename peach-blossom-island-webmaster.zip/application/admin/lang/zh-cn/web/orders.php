<?php

return [
    'Order_sn'                   => '订单号',
    'Type'                       => '订单类型',
    'User_id'                    => '用户ID',
    'Username'                   => '用户名',
    'Businessid'                 => '套餐ID/积分ID',
    'Pay_method_id'              => '支付方式ID',
    'Pay_method_name'            => '支付方式',
    'Pay_status'                 => '支付状态',
    'Create_time'                => '创建时间',
    'Update_time'                => '更新时间',
    'Type_vip'                   => 'VIP订单',
    'Type_score'                 => '积分订单',
    'Pay_status_success'         => '已支付',
    'Pay_status_wait'            => '待支付',
    'Pay_status_fail'            => '支付失败',
    'Pay_status_timeout'         => '已超时',
    'Pay_status_unknown'         => '未知',
];
