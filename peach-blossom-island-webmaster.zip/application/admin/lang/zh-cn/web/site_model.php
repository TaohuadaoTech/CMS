<?php

return [
    'Mode_id'                  => '模板ID',
    'Model_cover'              => '模板封面',
    'Mode_name'                => '模板名称',
    'Mode_version'             => '模板版本号',
    'Model_status'             => '状态',
    'Create_time'              => '模板下载时间',
    'Update_time'              => '更新时间',
    'Status_Enable'            => '启用',
    'Status_Disable'           => '禁用',
    'Model_download'           => '下载',
    'Model_select'             => '查看',
    'Model_download_remind'    => '确认要立即开始下载该模板吗？',
    'download failed'          => '下载失败',
];
