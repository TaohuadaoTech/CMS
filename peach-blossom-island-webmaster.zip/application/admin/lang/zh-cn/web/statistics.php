<?php

return [
    'Site_id'                   => '站点id',
    'Pv'                        => '浏览量',
    'Uv'                        => '访客数',
    'Rv'                        => '注册数',
    'Vv'                        => '播放量',
    'Mv'                        => '收款金额',
    'Start_time'                => '统计的起始时间',
    'End_time'                  => '统计的结束时间',
    'Create_time'               => '记录生成时间',
    'Download'                  => '导出Excel',
];
