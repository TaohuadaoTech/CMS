<?php

return [
    'Name'                      => '套餐名称',
    'Original_price'            => '套餐原价格',
    'Sale_price'                => '销售价格',
    'Integral'                  => '赠送积分',
    'Status'                    => '状态',
    'Create_time'               => '创建时间',
    'Update_time'               => '更新时间',
    'Status_Enable'             => '启用',
    'Status_Disable'            => '禁用',
];
