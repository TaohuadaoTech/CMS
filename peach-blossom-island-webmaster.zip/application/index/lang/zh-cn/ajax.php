<?php

return [
    'verify_fail'                       => '验证失败，请重试',
    'send_success'                      => '发送成功',
    'Email is incorrect'                => '邮箱不正确',
    'mail_code_find_fail'               => '邮箱验证码获取失败，请稍后重试',
];
