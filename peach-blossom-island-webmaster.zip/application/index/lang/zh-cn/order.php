<?php
return [
    'Pay_status_success'             => '已支付',
    'Pay_status_wait'                => '待支付',
    'Pay_status_fail'                => '支付失败',
    'Pay_status_timeout'             => '已超时',
    'Pay_status_unknown'             => '未知',
    'Pay_not_support'                => '该支付方式未支持，请选择其它支付方式',
];