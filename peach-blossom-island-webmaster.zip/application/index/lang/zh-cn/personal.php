<?php

return [
    'Sky VIP'               => '天VIP',
    'Integral'              => '个积分',
];