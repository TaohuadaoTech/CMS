<?php
return [
    'Video loss'                                         => '视频丢失',
    'Failed purchase'                                    => '购买失败，请稍后再试',
];